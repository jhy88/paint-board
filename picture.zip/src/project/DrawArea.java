package project;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

public class DrawArea extends JComponent {
    private BufferedImage image;
    private Graphics2D g2;
    private int prevX, prevY, currX, currY;
    private String currentShape = "Free Draw";
    private Color currentColor = Color.BLACK;
    private int currentStroke = 1;

    public DrawArea() {
        setDoubleBuffered(false);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                prevX = e.getX();
                prevY = e.getY();
            }

            public void mouseReleased(MouseEvent e) {
                currX = e.getX();
                currY = e.getY();
                if (g2 != null && !currentShape.equals("Free Draw") && !currentShape.equals("Eraser")) {
                    drawShape(prevX, prevY, currX, currY);
                    repaint();
                }
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                currX = e.getX();
                currY = e.getY();
                if (g2 != null) {
                    if (currentShape.equals("Free Draw") || currentShape.equals("Eraser")) {
                        g2.drawLine(prevX, prevY, currX, currY);
                        repaint();
                        prevX = currX;
                        prevY = currY;
                    }
                }
            }
        });
    }

    protected void paintComponent(Graphics g) {
        if (image == null) {
            image = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_ARGB);
            g2 = (Graphics2D) image.getGraphics();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            clear();
        }
        g.drawImage(image, 0, 0, null);
        if (g2 != null && currentShape != null && !currentShape.equals("Free Draw") && !currentShape.equals("Eraser")) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setColor(currentColor);
            g2d.setStroke(new BasicStroke(currentStroke));
            drawShape(g2d, prevX, prevY, currX, currY);
        }
    }

    public void clear() {
        g2.setPaint(Color.WHITE);
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.setPaint(currentColor);
        g2.setStroke(new BasicStroke(currentStroke));
        repaint();
    }

    public void setColor(Color color) {
        currentColor = color;
        g2.setPaint(color);
    }

    public void setEraser() {
        currentShape = "Eraser";
        g2.setPaint(Color.WHITE);
    }

    public void setShape(String shape) {
        currentShape = shape;
        if (!shape.equals("Eraser")) {
            g2.setPaint(currentColor);
        }
    }

    public void setStroke(int stroke) {
        currentStroke = stroke;
        g2.setStroke(new BasicStroke(stroke));
    }

    private void drawShape(int x1, int y1, int x2, int y2) {
        drawShape(g2, x1, y1, x2, y2);
    }

    private void drawShape(Graphics2D g2d, int x1, int y1, int x2, int y2) {
        switch (currentShape) {
            case "Line":
                g2d.drawLine(x1, y1, x2, y2);
                break;
            case "Rectangle":
                g2d.drawRect(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x2 - x1), Math.abs(y2 - y1));
                break;
            case "Oval":
                g2d.drawOval(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x2 - x1), Math.abs(y2 - y1));
                break;
            case "Eraser":
                g2d.setPaint(Color.WHITE);
                g2d.setStroke(new BasicStroke(currentStroke));
                g2d.drawLine(x1, y1, x2, y2);
                g2d.setPaint(currentColor);
                g2d.setStroke(new BasicStroke(currentStroke));
                break;
        }
    }
}
