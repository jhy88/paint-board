package project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main extends JFrame {
    private DrawArea drawArea;
    private JButton clearBtn, colorBtn, eraseBtn, lineBtn, rectBtn, ovalBtn, freeDrawBtn;
    private JSlider strokeSlider;
    private Color currentColor = Color.BLACK;
    private String currentShape = "Free Draw";
    private int currentStroke = 1;

    public Main() {
        setTitle("Java Paint");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);

        drawArea = new DrawArea();

        clearBtn = new JButton("Clear");
        clearBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                drawArea.clear();
            }
        });

        colorBtn = new JButton("Color");
        colorBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentColor = JColorChooser.showDialog(null, "Choose a color", currentColor);
                drawArea.setColor(currentColor);
            }
        });

        eraseBtn = new JButton("Eraser");
        eraseBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentShape = "Eraser";
                drawArea.setEraser();
            }
        });

        lineBtn = new JButton("Line");
        lineBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentShape = "Line";
                drawArea.setShape(currentShape);
            }
        });

        rectBtn = new JButton("Rectangle");
        rectBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentShape = "Rectangle";
                drawArea.setShape(currentShape);
            }
        });

        ovalBtn = new JButton("Oval");
        ovalBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentShape = "Oval";
                drawArea.setShape(currentShape);
            }
        });

        freeDrawBtn = new JButton("Free Draw");
        freeDrawBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentShape = "Free Draw";
                drawArea.setShape(currentShape);
            }
        });

        strokeSlider = new JSlider(JSlider.HORIZONTAL, 1, 20, 1);
        strokeSlider.setMajorTickSpacing(1);
        strokeSlider.setPaintTicks(true);
        strokeSlider.setPaintLabels(true);
        strokeSlider.addChangeListener(e -> {
            currentStroke = strokeSlider.getValue();
            drawArea.setStroke(currentStroke);
        });

        JPanel panel = new JPanel();
        panel.add(clearBtn);
        panel.add(colorBtn);
        panel.add(eraseBtn);
        panel.add(lineBtn);
        panel.add(rectBtn);
        panel.add(ovalBtn);
        panel.add(freeDrawBtn);
        panel.add(new JLabel("Stroke:"));
        panel.add(strokeSlider);

        add(panel, BorderLayout.NORTH);
        add(drawArea, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
            }
        });
    }
}
